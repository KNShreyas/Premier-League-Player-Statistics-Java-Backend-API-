package com.example.pl_connect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
